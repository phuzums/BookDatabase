#pragma once
#include "Book.h"

class CashierBook : public Book
{
public:
//	CashierBook();
//	CashierBook(some cashier specific stuff?)

};