// CIS Final Project - Nathan, Yusuf, Matthew, and Krissi
// Finished on 3/20/2019
// CIS 22B - 03Y
////////////////////////////////////////////

#define CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <iomanip>
#include "BookDB.h"

// Default Constructor
BookDB::BookDB()
{
	
}

/////////////////////////////////////////////////////////////////////////
//Pre:  None
//Post: Initializes a BookDB object and its variables
/*
this is the constructor to the BookDB
it accepts arguments, a string filename that and a string sFIlename
set the filename string parameter to the filename of the book databse
set the sFilename string parameter to the filename of the book databse where the sales information is stored

sets totalWholesaleValue to 0
sets totalRetailValue to 0
sets currentNetProfit to 0
sets currentSalesAmount to 0

dyamically allocates memory for the Book array
runs the readBooks function that reads the file and puts all info about books in listFilename to the books array
runs the readSalesData function passing into it salesFilename that puts the currentNetProfit and currentSalesAmount into the salesFile
*/
BookDB::BookDB(std::string filename, std::string sFilename) : BookList()
{
	listFilename		= filename;
	salesFilename		= sFilename;

	totalWholesaleValue = 0;
	totalRetailValue	= 0;
	currentNetProfit	= 0;
	currentSalesAmount	= 0;
	salesTax			= 0.09;

	books = new Book[MAX_BOOKS];
	readBooks();
	readSalesData(salesFilename);
}

/////////////////////////////////////////////////////////////////////////
//Pre:  BookDB Exists
//Post: Nothing additional to the base-class's version is needed here.
BookDB::~BookDB()
{

}

/////////////////////////////////////////////////////////////////////////
//Pre:  BookDB Exists and there is data to be written to both the files
//Post: Both data output functions are called and their error data is passed
//		to cout.
void BookDB::writeOutput()
{
	std::cout << "\nWritting Database to file " << listFilename << "... ";
	if (writeBooks())
		std::cout << "\nSuccess!\n";
	else
		std::cout << "Error writting to file...\n";

	std::cout << "\nWritting Sales data to file " << salesFilename << "... ";
	if (writeSalesData(salesFilename))
		std::cout << "\nSuccess!\n";
	else
		std::cout << "Error writting to file...\n";
}

/////////////////////////////////////////////////////////////////////////
//Pre:  books has been initialized
//Post: returns the wholesale value of all the books combined
double BookDB::getWholesaleValue()
{
	return totalWholesaleValue;
}

/////////////////////////////////////////////////////////////////////////
//Pre:  books has been initialized
//Post: Retail Value is returned
double BookDB::getRetailValue()
{
	return totalRetailValue;
}

/////////////////////////////////////////////////////////////////////////
//Pre:  books has been initialized
//Post: Net profit is returned
double BookDB::getNetProfit()
{
	return currentNetProfit;
}

/////////////////////////////////////////////////////////////////////////
//Pre:  books has been initialized
//Post: Salestax is returned
double BookDB::getTax()
{
	return salesTax;
}

// ============Mutators==============
/////////////////////////////////////////////////////////////////////////
//Pre:  Filename is valid and bk is initialized to hold at least
//      MAX_BOOKS
//Post: bk is filled with books from the file <filename>.
//      WholesaleValue and retailValue are updated as the books
//      are moved into the books array
/*
sets the number of books to 0
sets both totalRetailValue and totalWholesaleValue to 0
opens the filename listFilename
if the listFile did not open properly
return false
sets a temp to 0
do while loop that iterates while it is not the end of the file
inializes a string variable tstr
reads the first word in the line and puts it in the book array at the index of numBooks
inializes a tc char varibale
reads the space character from listFile
stores the ISBN into the temp variable
if the temp is 0 (the ISBN is 0)
iniailizes an int variable tempint
inializes a double variable tempdbl
reads the characters in the listFile and stores it in tstr until the } character
reads the characters in the listFile and stores it in tstr until the } character
reads the characters in the listFile and stores it in tstr until the } character
reads the next word in the listFile and stores it in tempint variable
reads the next word in the listFile and stores it in tempint variable
reads the next word in the listFile and stores it in tempint variable
reads the next word in the listFile and stores it in tempint variable
increments the value of books[temp].quantity by tempint
reads the next word of listFile and puts it into tempdbl
increments totalRetailValue by the product of tempdbl and tempint
reads the next word and puts it into the tempdbl variable
increments totalWholesaleValue by the product of tempdbl and tempint
reads the line in listFIle until the } and stores the string in tstr
stores the tstr variable in title element of the books object

	 reads the line in listFIle until the } and stores the string in tstr
	stores the tstr variable in author element of the books object

	reads the line in listFIle until the } and stores the string in tstr
	stores the tstr variable in publisher element of the books object

	reads the word in the listFile file and stores it in the addedOn.month attribute of the book object
	reads the word in the listFile file and stores it in the addedOn.day attribute of the book object
	reads the word in the listFile file and stores it in the addedOn.year attribute of the book object
	reads the word in the listFile file and stores it in the quantity attribute of the book object
	reads the word in the listFile file and stores it in the .retailCost attribute of the book object
	reads the word in the listFile file and stores it in the .wholesaleCost attribute of the book object
*/
bool BookDB::readBooks()
{
	numBooks = 0;
	totalRetailValue = totalWholesaleValue = 0;

	listFile.open(listFilename);

	if (!listFile)
		return false;

	int temp = 0;
	do
	{
		std::string tstr;

		listFile >> books[numBooks].ISBN;
		char tc = ' ';
		listFile >> tc; //Dummy char to read the seperator between isbn & books (used in case a book title starts with a number)


		// Search for an existing entry
		temp = findBook(books[numBooks].ISBN);

		// increase quantity if a match was found
		if (temp > 0)
		{
			int tempint;
			double tempdbl;
			std::getline(listFile, tstr, '}');
			std::getline(listFile, tstr, '}');
			std::getline(listFile, tstr, '}');
			listFile >> tempint; //day
			listFile >> tempint; //month
			listFile >> tempint; //year
			listFile >> tempint;
			books[temp].quantity += tempint;
			listFile >> tempdbl;
			totalRetailValue += tempdbl * (double)tempint;
			listFile >> tempdbl;
			totalWholesaleValue += tempdbl * (double)tempint;

			continue;
		}

		std::getline(listFile, tstr, '}');
		books[numBooks].title = tstr;
		std::getline(listFile, tstr, '}');
		books[numBooks].author = tstr;
		std::getline(listFile, tstr, '}');
		books[numBooks].publisher = tstr;
		listFile >> books[numBooks].addedOn.month;
		listFile >> books[numBooks].addedOn.day;
		listFile >> books[numBooks].addedOn.year;
		listFile >> books[numBooks].quantity;
		listFile >> books[numBooks].retailCost;
		listFile >> books[numBooks].wholesaleCost;

		totalRetailValue += books[numBooks].retailCost * (double)books[numBooks].quantity;
		totalWholesaleValue += books[numBooks].wholesaleCost * (double)books[numBooks].quantity;

		numBooks++;


	} while (!listFile.eof());

	listFile.close();
	return true;
}

/////////////////////////////////////////////////////////////////////////
//Pre:	Filename is valid and not currently being r/w'd to. We're assuming the
//		file will never shrink (as only quantities are set to zero, not removed)
//Post: Book array is formatted and outputted to a file. The filename should
//      always be listFile? as you want to 'edit' the database you've opened,
//      not copy it.
/*
if the file fails to open
return false
open the file
if the file fails to opne
return false
loop for the number of books in the database
writes the books isbn to listFle
writes the books title to listFle
writes the books authir to listFle
writes the books publisher to listFle
writes the books month that it was added to listFle
writes the books day it was addedto listFle
writes the books year that it was added to listFle
writes the books quanitity to listFle
setPrcision to make it look nice
writes the books retailCost to listFle
setprecision to make it look good
writes the books wholesaleCost to listFile
if the index is less than the numBooks in the array
add a newline character
*/
bool BookDB::writeBooks()
{
	if (listFile.is_open())
		return false;

	listFile.open(listFilename);
	
	if (!listFile.is_open())
		return false;

	for (int idx = 0; idx < numBooks; idx++)
	{
		listFile << books[idx].ISBN << '}';
		listFile << books[idx].title << '}';
		listFile << books[idx].author << '}';
		listFile << books[idx].publisher << '}';
		listFile << books[idx].addedOn.month << ' ';
		listFile << books[idx].addedOn.day << ' ';
		listFile << books[idx].addedOn.year << ' ';
		listFile << books[idx].quantity << ' ';
		listFile << std::fixed << std::setprecision(2);
		listFile << books[idx].retailCost << ' ';
		listFile << std::fixed << std::setprecision(2);
		listFile << books[idx].wholesaleCost;
		listFile.unsetf(std::ios_base::fixed);
		if (idx < numBooks - 1)
			listFile << '\n';
	}

	listFile.close();
	return true;
}

/////////////////////////////////////////////////////////////////////////
//Pre:  filename is valid
//Post: 
/*
open the filename parameter for output and appending
if the file failed to open
return false
close the file
open the file
if it is the end of the file
set currentNetProfit to 0
close the file
return true
output the currentNetProfit and currentSalesAmount to the salesFile
close the file
return true
*/
bool	BookDB::readSalesData(std::string filename)
{

	// Attempt to create or open the file
	salesFile.open(filename,std::fstream::out | std::fstream::app);
	if (!salesFile.is_open())
		return false;

	// Reopen for input after creating
	salesFile.close();
	salesFile.open(filename, std::fstream::in);
	if (salesFile.eof())
	{
		currentNetProfit = 0.0;
		salesFile.close();
		return true;
	}

	salesFile >> currentNetProfit >> currentSalesAmount;
	salesFile.close();
	return true;
}

/////////////////////////////////////////////////////////////////////////
//Pre:  
//Post: 
/*
open the filename parameter for output
if the file fails to open
return false
cout the currentNetProfit
writing the currentNetProfit to the file that is specified in the filename parameter
write currentSalesAmount to the salesFile
close the file
return true
*/
bool	BookDB::writeSalesData(std::string filename)
{
	salesFile.open(filename, std::fstream::out);
	if (!salesFile.is_open())
		return false;
	std::cout << "\nNet Profit for this Session is $" << std::fixed << std::setprecision(2) << currentNetProfit;
	salesFile << std::setprecision(2) << std::fixed << currentNetProfit;
	salesFile << std::endl << currentSalesAmount;

	salesFile.close();
	return true;
}



/////////////////////////////////////////////////////////////////////////
//Pre:  iunno?
//Post: A book of ISBN is sold from the database IF the ISBN is found AND the
//      quantity is > 0. Retail and wholesale value of the databse is adjusted
//      for the book. Returns the price of the book sold and 0 if there was an error (assuming nothing is free).
/*
if the index passed is less than 0
return 0.0
if the quantity attribute is less than or equal to 0.0
return 0.0
decrement quantityItems
decrement the quantity attribute of the book
decrement the retailValue by the retail cost of the boook
decrement the totalWholesaleValue by the wholesaleValue cost of the boook
add the currentNetProfit by the difference of the book's retailCost and the book's wholesaleCost
cout the currentNetProfit
increment the currentSalesAmount by the retailCost
return the retailCost of the book

*/
double BookDB::sellBook(unsigned long ISBN)
{
	int idx = findBook(ISBN);
	
	// Error checking
	if (idx < 0)
		return 0.0;
	if (books[idx].quantity <= 0)
		return 0.0;

	quantityItems--;
	books[idx].quantity--;
	totalRetailValue	-= books[idx].retailCost;
	totalWholesaleValue -= books[idx].wholesaleCost;

	currentNetProfit += (books[idx].retailCost - books[idx].wholesaleCost);
	std::cout << "Book sold." << std::endl;
	currentSalesAmount += books[idx].retailCost;

	return books[idx].retailCost;
}

/////////////////////////////////////////////////////////////////////////
//Pre:  
//Post: 
/*
if the index passed is less than 0
return 0.0
if the quantity attribute is less than or equal to 0.0
return 0.0
decrement quantityItems
decrement the quantity attribute of the book
decrement the retailValue by the retail cost of the boook
decrement the totalWholesaleValue by the wholesaleValue cost of the boook
add the currentNetProfit by the difference of the book's retailCost and the book's wholesaleCost
cout the currentNetProfit
return the retailCost of the book

*/
double BookDB::sellBook(int idx)
{
	// Error checking
	if (idx < 0)
		return 0.0;
	if (books[idx].quantity <= 0)
		return 0.0;

	quantityItems--;
	books[idx].quantity--;
	totalRetailValue -= books[idx].retailCost;
	totalWholesaleValue -= books[idx].wholesaleCost;

	currentNetProfit += (books[idx].retailCost - books[idx].wholesaleCost);
	std::cout << "Book sold." << std::endl;
	currentSalesAmount += books[idx].retailCost;


	return books[idx].retailCost;
}

/////////////////////////////////////////////////////////////////////////
//Pre:  
//Post: 
void BookDB::addBook(const Book &bk)
{
	// Either way, increase value tracking stuff
	totalRetailValue += bk.retailCost * bk.quantity;
	totalWholesaleValue += bk.wholesaleCost * bk.quantity;

	BookList::addBook(bk);
}

/////////////////////////////////////////////////////////////////////////
//Pre:  
//Post: 
void BookDB::modifyBook(int idx, Book replacement)
{
	// De-register sales date just in-case that is being modified
	totalRetailValue -= books[idx].retailCost * books[idx].quantity;
	totalWholesaleValue -= books[idx].wholesaleCost * books[idx].quantity;
	quantityItems -= books[idx].quantity;

	// Add the new book's value to the database
	totalRetailValue += replacement.retailCost * replacement.quantity;
	totalWholesaleValue += replacement.wholesaleCost * replacement.quantity;
	quantityItems += replacement.quantity;

	// Call the base class's version to finish off the job
	BookList::modifyBook(idx, replacement);
}



/////////////////////////////////////////////////////////////////////////
//Pre:  sm is a valid sort method. books array should hold > 1 book
//Post: books array is sorted through using the appropriate SORT_METHOD
/*
set a books pointer to the value of the getBooks function
sets the numBooks variable to the getNumsBooks function
if the number of books is less than 1
return false
if the sm parameter is quantity
inialize i j and min_idx
do a loop for the number of books()
sets the min_indx to the i value
loops through and checks if the j quantity is less than the min idx
if so it resets the min_indx to the value of j
swaps books[min_idx] with books[i]
if the sm parameter is cost
sets the min_indx to the i value
loops through and checks if the j quantity is less than the min idx
if so it resets the min_indx to the value of j
swaps books[min_idx] with books[i]
if the sm parameter is age
sets the min_indx to the i value
loops through and checks if the j quantity is less than the min idx
if so it resets the min_indx to the value of j
swaps books[min_idx] with books[i]
*/
bool BookDB::sortBooks(SORT_METHOD sm)
{
	//is the array > 1?
	//if no, return 0
	Book *books = getBooks();
	int numBooks = getNumBooks();
	if (numBooks <= 1) {
		return false;
	}

	//loop through books using books array and numBooks
	//compare values determined by the sm (case switch?)
	//move and sort the books
	if (sm == QUANTITY) {
		int i, j, min_idx;

		// One by one move boundary of unsorted subarray
		for (i = 0; i < numBooks - 1; i++)
		{
			min_idx = i;
			for (j = i + 1; j < numBooks; j++)
				if (books[j].quantity < books[min_idx].quantity)
					min_idx = j;
			// Swap
			Book temp = books[min_idx];
			books[min_idx] = books[i];
			books[i] = temp;
		}
		return true;
	}
	else if (sm == COST) {
		int i, j, min_idx;

		// One by one move boundary of unsorted subarray
		for (i = 0; i < numBooks - 1; i++)
		{
			min_idx = i;
			for (j = i + 1; j < numBooks; j++)
				if (books[j].retailCost < books[min_idx].retailCost)
					min_idx = j;
			// Swap
			std::swap(books[i], books[min_idx]);
			/*Book temp = books[min_idx];
			books[min_idx] = books[j];
			books[j] = temp;*/
		}
		return true;
	}
	else if (sm == AGE) {
		int i, j, min_idx;

		// One by one move boundary of unsorted subarray
		for (i = 0; i < numBooks - 1; i++)
		{
			min_idx = i;
			for (j = i + 1; j < numBooks; j++)
			{
				long temp = books[j].addedOn.day + books[j].addedOn.month * 31 + books[j].addedOn.year * 365;
				long temp2 = books[min_idx].addedOn.day + books[min_idx].addedOn.month * 31 + books[min_idx].addedOn.year * 365;
				if (temp < temp2)
					min_idx = j;
			}
		//		if (books[j].addedOn.day <= books[min_idx].addedOn.day || books[j].addedOn.month <= books[min_idx].addedOn.month || books[j].addedOn.year <= books[min_idx].addedOn.year)
			//		if (books[j].addedOn.month <= books[min_idx].addedOn.month || books[j].addedOn.year <= books[min_idx].addedOn.year)
				//		if (books[j].addedOn.year < books[min_idx].addedOn.year)
					//		min_idx = j;
			// Swap
			std::swap(books[i], books[min_idx]);
				//Book temp = books[min_idx];
				//books[min_idx] = books[i];
				//books[i] = temp;
			
		}
		return true;
	}
	return false; // end-of-function return val needed incase it gets reached somehow
}

/////////////////////////////////////////////////////////////////////////
//Pre:  stuff
//Post: Pretty much the same as sellBook, except it can remove multiple books at
//		one and returns true if successful and false if there was an error
/*
inializes a variable idx and it is the return value of the findBook function
if idx < 0
return false
if the quantity of the book is less than 1 more than the quantity parameter
return false
decrement the quantityItems by quantity
decrement the quantity of the books objects by the quantity parameter passed
decrement the totalRetailValue by the product of the retailCost of the book and the quantity parameter
decrement the totalWholesaleValue by the product of the wholeSaleCost of the book and the quantity

*/
bool    BookDB::removeBook(unsigned long ISBN, int quantity)
{
	int idx = findBook(ISBN);
	if (idx < 0)
		return false;
	if (books[idx].quantity < quantity)
		return false;

	quantityItems -= quantity;

	totalRetailValue -= books[idx].retailCost * quantity;
	totalWholesaleValue -= books[idx].wholesaleCost * quantity;
	BookList::removeBook(ISBN, quantity);
	return 1;
}

/////////////////////////////////////////////////////////////////////////
//Pre:  
//Post: 
/*
loop for the number of books in the array
cout the string book and the index the loop is on
if the sm parameter passed is age
cout the title of the book followed by the string age followed by the day the book was added followed by a / followed by the month it was added and the year it was added
if the sm parameter passed is cost
cout the title of the book followed by the stringcost : $ followed by the retailCost
if the sm parameter passed is quantity
cout the title of the book followed by the string quantity followed by the quantity
if the verbosity parameter is greater than 1
cout the string author followed by the author of the book followed by the publisher string followed by the publisher of the book
if the verbosity parameter is greater than 0
cout the string ISBN followed by the ISBN of the book
*/
void	BookDB::printByMethod(int verbosity = 0, SORT_METHOD sm = SORT_METHOD::QUANTITY)
{
	for (int idx = 0; idx < numBooks; idx++)
	{
		std::cout << "\nBook " << (idx > 9 ? "" : " ") << idx << " : ";
		if (sm == SORT_METHOD::AGE)
		{
			std::cout << std::left << std::setfill('.');
			std::cout << std::setw(50) << books[idx].title << "Age : " << (books[idx].addedOn.month < 10 ? " " : "") << books[idx].addedOn.month
				<< '/' << (books[idx].addedOn.day < 10 ? " " : "") << books[idx].addedOn.day << '/' << books[idx].addedOn.year;
		}
		if (sm == SORT_METHOD::COST)
		{
			std::cout << std::left << std::setfill('.');
			std::cout << std::setw(42) << books[idx].title << "Cost : $"
				<< std::fixed << std::setprecision(2) << books[idx].retailCost;
			// kind of weird, but print a space if the quantity is over ten to make up for the extra digit - prettiness up to 99 items!
			std::cout << std::endl << "Quantity " << std::setw(35) << books[idx].quantity << "Total Retail : $" << std::fixed << std::setprecision(2) << books[idx].retailCost * books[idx].quantity << std::endl;
		}
		if (sm == SORT_METHOD::QUANTITY)
		{
			std::cout << std::left << std::setfill('.');
			std::cout << std::setw(50) << books[idx].title << "Quantity : " 
				<< books[idx].quantity;
		}
		if (sm == SORT_METHOD::WHOLESALE)
		{
			std::cout << std::left << std::setfill('.');
			std::cout << std::setw(40) << books[idx].title << "Wholesale : $"
				<< std::fixed << std::setprecision(2) << books[idx].wholesaleCost;
			
			std::cout << std::setfill(' ') << std::endl << "Quantity " <<  std::setw(35) << books[idx].quantity  << "Total Wholesale : $" << std::fixed << std::setprecision(2) << books[idx].wholesaleCost * books[idx].quantity << std::endl;
		}
		if (sm == SORT_METHOD::SIMPLE)
		{
			std::cout << std::left << std::setfill('.');
			std::cout << std::setw(32) << books[idx].title << "by " << books[idx].author << '.';
		}
		if (verbosity > 1)
			std::cout << std::endl << "Author : " << books[idx].author << "... Publisher : " << books[idx].publisher;
		if (verbosity > 0)
			std::cout << std::endl << "ISBN : " << books[idx].ISBN << std::endl;
	}
}