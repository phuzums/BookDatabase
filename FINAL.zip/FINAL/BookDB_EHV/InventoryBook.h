#pragma once
#include "Book.h"

class InventoryBook : public Book
{
public:
	// InventoryBook();
	// InventoryBook(some junk);

};